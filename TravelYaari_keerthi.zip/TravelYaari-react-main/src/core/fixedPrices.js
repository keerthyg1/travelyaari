export const prices = [
    {
        _id: 0,
        name: "Any",
        array: []
    },
    {
        _id: 1,
        name: "₹0 to ₹1999",
        array: [0, 1999]
    },
    {
        _id: 2,
        name: "₹1999 to ₹4999",
        array: [1999, 4999]
    },
    {
        _id: 3,
        name: "₹5000 to ₹7999",
        array: [5000, 7999]
    },
    {
        _id: 4,
        name: "₹8000 to ₹9999",
        array: [8000, 9999]
    },
    {
        _id: 5,
        name: "More than ₹10000",
        array: [10000, 50000]
    }
];
