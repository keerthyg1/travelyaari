import React from 'react'

export default function Footer1() {
    return (
        <div>
            
        </div>
    )
}
